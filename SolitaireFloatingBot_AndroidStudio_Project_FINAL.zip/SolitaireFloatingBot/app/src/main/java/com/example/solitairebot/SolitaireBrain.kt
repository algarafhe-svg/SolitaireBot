package com.example.solitairebot

import android.graphics.Bitmap
import android.util.Log
import android.widget.Toast

/** Autonomous Jawaker Klondike controller. It acts only on frames whose visible cards were read. */
object SolitaireBrain {
    private const val TAG = "SolitaireBrain"
    @Volatile private var enabled = false
    @Volatile private var paused = false
    private var lastSignature = ""
    private var lastActionAt = 0L
    private var pendingSignature = ""
    private var pendingSince = 0L
    private var redeals = 0
    private var lastActionKey = ""
    private var unchangedRetries = 0
    private var unreadableFrames = 0
    private const val MAX_UNREADABLE_FRAMES = 15
    private const val MAX_REDEALS = 3

    private sealed class Action { abstract val score: Int; abstract val key: String
        data class Drag(val sx: Float, val sy: Float, val dx: Float, val dy: Float, override val score: Int, override val key: String, val why: String) : Action()
        data class Tap(val x: Float, val y: Float, override val score: Int, override val key: String, val why: String) : Action()
    }

    fun start() {
        enabled = true; paused = false; lastSignature = ""; pendingSignature = ""
        lastActionAt = 0L; pendingSince = 0L; redeals = 0; lastActionKey = ""; unchangedRetries = 0; unreadableFrames = 0
        SolitaireAccessibilityService.instance?.startAutoPlay()
    }
    fun isPaused(): Boolean = paused
    fun pause() { paused = true; SolitaireAccessibilityService.instance?.pauseAutoPlay() }
    fun resume() { if (enabled) { paused = false; SolitaireAccessibilityService.instance?.resumeAutoPlay() } }
    fun stop() { enabled = false; paused = false; pendingSignature = ""; SolitaireAccessibilityService.instance?.stopAutoPlay() }

    @Synchronized fun onFrame(width: Int, height: Int, bitmap: Bitmap, tokens: List<OcrToken>) {
        if (!enabled || paused) return
        val service = SolitaireAccessibilityService.instance ?: return
        val board = JawakerVision.read(bitmap, tokens)
        if (board == null) {
            unreadableFrames++
            if (unreadableFrames >= MAX_UNREADABLE_FRAMES) {
                paused = true
                service.pauseAutoPlay()
                unreadableFrames = 0
                Toast.makeText(service, "تعذّرت قراءة الأوراق بوضوح؛ أوقفت اللعب لتجنّب حركة خاطئة", Toast.LENGTH_LONG).show()
                Log.w(TAG, "Paused after repeated low-confidence board reads")
            }
            return
        }
        unreadableFrames = 0
        val now = System.currentTimeMillis()
        if (board.signature == pendingSignature && pendingSignature.isNotEmpty()) {
            if (now - pendingSince < 2600L) return
            // If the board did not change after a gesture, retry once only; never drag forever.
            if (unchangedRetries >= 1) {
                paused = true
                service.pauseAutoPlay()
                Log.i(TAG, "Board did not change after retry; paused to avoid repeated wrong gestures")
                return
            }
            unchangedRetries++
            pendingSignature = ""
        } else if (board.signature != lastSignature) {
            unchangedRetries = 0
            pendingSignature = ""
        } else if (pendingSignature.isEmpty()) {
            // A stable state with no available move was already evaluated; wait for a new frame state.
            return
        }
        if (board.signature == lastSignature && now - lastActionAt < 850L) return
        if (board.signature == lastSignature && pendingSignature.isNotEmpty()) return
        val action = choose(board, width.toFloat(), height.toFloat()) ?: run {
            lastSignature = board.signature
            return
        }
        if (now - lastActionAt < 900L) return
        val accepted = when (action) {
            is Action.Drag -> service.dragCoordinates(action.sx, action.sy, action.dx, action.dy, 430)
            is Action.Tap -> service.tapCoordinates(action.x, action.y)
        }
        lastSignature = board.signature
        pendingSignature = board.signature
        pendingSince = now
        lastActionAt = now
        if (accepted) {
            lastActionKey = action.key
            if (action.key.startsWith("STOCK:RECYCLE")) redeals++
        }
        if (accepted && action.key == "FINISH") {
            enabled = false
            paused = true
            service.pauseAutoPlay()
        }
        Log.i(TAG, "Action ${action.javaClass.simpleName}: ${when(action) { is Action.Drag -> action.why; is Action.Tap -> action.why }} accepted=$accepted")
    }

    private fun choose(b: JawakerVision.Board, w: Float, h: Float): Action? {
        val moves = mutableListOf<Action>()
        val cols = b.columns
        // Move a tableau top card to its matching foundation when this does not strand a low card.
        for (src in 0..6) {
            val pile = cols[src]
            val top = pile.lastOrNull() ?: continue
            val foundation = b.foundations[top.card.suit] ?: 0
            if (top.card.suitKnown && KlondikeRules.canPlaceOnFoundation(top.card, foundation)) {
                if (KlondikeRules.isSafeFoundationAdvance(top.card, b.foundations)) {
                    val reveals = pile.size == 1 && b.hidden[src] > 0
                    moves += Action.Drag(top.x, top.y + h*.012f, foundationX(foundationTarget(top.card.suit,b),w), h*.282f,
                        72 + top.card.rank + if (reveals) 125 else 0, "F:T:$src:${top.card.rank}${top.card.suit}", if (reveals) "foundation and reveal hidden card" else "tableau to foundation")
                }
            }
        }
        // Move a waste card to foundation or tableau.
        b.waste?.let { waste ->
            val f = b.foundations[waste.card.suit] ?: 0
            if (waste.card.suitKnown && KlondikeRules.canPlaceOnFoundation(waste.card, f) &&
                KlondikeRules.isSafeFoundationAdvance(waste.card, b.foundations)) {
                moves += Action.Drag(waste.x, waste.y + h*.012f, foundationX(foundationTarget(waste.card.suit,b),w), h*.282f,
                    78 + waste.card.rank, "F:W:${waste.card.rank}${waste.card.suit}", "waste to foundation")
            }
            for (dst in 0..6) {
                val target = cols[dst].lastOrNull()?.card
                if (KlondikeRules.canPlaceOnTableau(waste.card, target) && (target != null || b.hidden[dst] == 0)) {
                    val tx = centersX(dst,w); val ty = cols[dst].lastOrNull()?.y?.plus(h*.012f) ?: h*.355f
                    moves += Action.Drag(waste.x, waste.y + h*.012f, tx, ty, 46, "W:$dst:${waste.card.rank}${waste.card.color}", "waste to tableau")
                }
            }
        }
        // Tableau stack transfers; moving the whole exposed run is legal only if alternating and descending.
        for (src in 0..6) {
            val pile = cols[src]
            if (pile.isEmpty()) continue
            for (start in pile.indices) {
                val run = pile.drop(start)
                if (!KlondikeRules.isValidRun(run.map { it.card })) continue
                val moving = run.first()
                for (dst in 0..6) {
                    if (src == dst) continue
                    val target = cols[dst].lastOrNull()?.card
                    if (!KlondikeRules.canPlaceOnTableau(moving.card, target)) continue
                    if (target == null && b.hidden[dst] != 0) continue
                    val exposesHidden = start == 0 && b.hidden[src] > 0
                    val emptiesColumn = start == 0 && pile.size == run.size && b.hidden[src] == 0
                    val score = (if (exposesHidden) 150 else 0) + (if (target == null) 55 else 0) + run.size * 3 + (if (emptiesColumn) 4 else 0)
                    val fromY = moving.y + h*.012f
                    val targetY = cols[dst].lastOrNull()?.y?.plus(h*.012f) ?: h*.355f
                    moves += Action.Drag(moving.x, fromY, centersX(dst,w), targetY, score, "T:$src:$dst:${moving.card.rank}:${moving.card.color}:$start", if (exposesHidden) "reveal hidden card" else "tableau sequence")
                }
            }
        }
        // Stock draw is a candidate, not an unconditional fallback: a safe foundation move or
        // a move that reveals a hidden card should beat a blind draw, while a weak shuffle move should not.
        val stockX = w * .918f; val stockY = h * .282f
        if (b.stockAvailable) moves += Action.Tap(stockX, stockY, 34, "STOCK:DRAW", "draw next three stock cards")
        else if (b.waste != null && redeals < MAX_REDEALS) {
            moves += Action.Tap(stockX, stockY, 10, "STOCK:RECYCLE:${redeals + 1}",
                "recycle waste pile (${redeals + 1}; extra passes cost points)")
        }
        if (moves.isNotEmpty()) return moves.maxByOrNull { move ->
            move.score - if (isImmediateReverse(move.key, lastActionKey)) 110 else 0
        }
        if (!b.stockAvailable && (b.waste == null || redeals >= MAX_REDEALS)) {
            return Action.Tap(w * .785f, h * .912f, 1, "FINISH", "finish after all moves and stock cycles are exhausted")
        }
        return null
    }


    private fun isImmediateReverse(candidate: String, previous: String): Boolean {
        val a = candidate.split(':'); val b = previous.split(':')
        return a.size == 6 && b.size == 6 && a[0] == "T" && b[0] == "T" &&
            a[1] == b[2] && a[2] == b[1] && a[3] == b[3] && a[4] == b[4]
    }

    private fun foundationTarget(suit: Char, b: JawakerVision.Board): Int {
        b.foundationSlots[suit]?.let { return it }
        val used = b.foundationSlots.values.toSet()
        return (0..3).firstOrNull { it !in used } ?: 0
    }
    private fun foundationX(slot: Int, w: Float): Float = floatArrayOf(.083f,.223f,.362f,.501f)[slot.coerceIn(0,3)] * w
    private fun centersX(col: Int, w: Float): Float = floatArrayOf(.083f,.223f,.362f,.501f,.640f,.779f,.918f)[col] * w
}
