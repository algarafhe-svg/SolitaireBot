package com.example.solitairebot

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Fixed-layout vision adapter for the 674x1536 Jawaker portrait table shown by the user.
 * All coordinates are proportional, so the same layout works at other screen resolutions.
 * Rank comes from on-device ML Kit OCR; red/black comes from the corner glyph and the exposed card suit
 * is confirmed from the larger central symbol before any foundation move.
 */
internal object JawakerVision {
    data class Seen(val card: Card, val x: Float, val y: Float, val cardLeft: Float, val cardTop: Float, val column: Int = -1)
    data class Board(
        val columns: List<List<Seen>>,
        val hidden: List<Int>,
        val foundations: Map<Char, Int>,
        val foundationSlots: Map<Char, Int>,
        val waste: Seen?,
        val stockAvailable: Boolean,
        val signature: String
    )

    private val centers = floatArrayOf(.083f, .223f, .362f, .501f, .640f, .779f, .918f)
    private val rankRegex = Regex("(?i)^(10|[2-9]|A|J|Q|K)[HDSC]?$")
    private val largeTemplates: Map<Char, List<IntArray>> = mapOf(
        'H' to listOf(
            intArrayOf(0x0, 0x0, 0x1f9f8, 0x3fffc, 0x3fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x3fffc, 0x1fffc, 0x1fff8, 0xfff0, 0x7fe0, 0x3fc0, 0x1f80, 0x700, 0x0, 0x0),
            intArrayOf(0x0, 0x0, 0xf0f8, 0x1fdfc, 0x3fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x3fffc, 0x3fffc, 0x1fff8, 0xfff0, 0x7fe0, 0x1fc0, 0xf00, 0x0, 0x0),
            intArrayOf(0x0, 0x0, 0x1f0f0, 0x3fdfc, 0x7fffc, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffe, 0x3fffc, 0x3fffc, 0x1fff8, 0xfff0, 0x7fe0, 0x3fc0, 0x1f80, 0x0, 0x0),
        ),
        'D' to listOf(
            intArrayOf(0x0, 0x600, 0xf00, 0x1f80, 0x3fc0, 0x7fc0, 0xfff0, 0x1fff8, 0x3fff8, 0x7fffc, 0x7fffe, 0x3fffc, 0x3fffc, 0x1fff0, 0xfff0, 0x7fe0, 0x3fc0, 0x1f80, 0xf00, 0x0),
            intArrayOf(0x0, 0x600, 0xf00, 0x1f80, 0x3fc0, 0x7fe0, 0xfff0, 0x1fff0, 0x3fff8, 0x7fffc, 0x7fffc, 0x3fffc, 0x3fff8, 0x1fff0, 0xffe0, 0x7fc0, 0x3f80, 0x1f80, 0xf00, 0x0),
            intArrayOf(0x0, 0x600, 0xf00, 0x1f80, 0x3fc0, 0x7fe0, 0xfff0, 0x1fff0, 0x3fff8, 0x7fffc, 0x7fffe, 0x3fffc, 0x1fff8, 0x1fff0, 0xffe0, 0x7fe0, 0x3fc0, 0x1f80, 0xf00, 0x0),
            intArrayOf(0x0, 0x0, 0x600, 0xf00, 0x1f80, 0x3fc0, 0x7fe0, 0xfff0, 0x1fff8, 0x3fff8, 0x7fffc, 0x7fffe, 0x7fffe, 0x7fffc, 0x3fff8, 0x1fff0, 0xffe0, 0x7fe0, 0x0, 0x0),
        ),
        'C' to listOf(
            intArrayOf(0x0, 0xf00, 0x1f80, 0x1f80, 0x3f80, 0x3f80, 0x3f80, 0x1f80, 0x1cf38, 0x7e6fe, 0x7f7fe, 0x7fffe, 0x7f6fe, 0x3e67c, 0x600, 0xf00, 0x1f00, 0x3fc0, 0x3fc0, 0x0),
            intArrayOf(0x0, 0x600, 0xf00, 0x1f80, 0x3f80, 0x3f80, 0x3f80, 0x1f80, 0x1f00, 0x3ee7c, 0x7f6fe, 0x7fffe, 0x7f6fe, 0x7e6fe, 0x1c638, 0xe00, 0xf00, 0x1f80, 0x3f80, 0x0),
            intArrayOf(0x0, 0x600, 0x1f80, 0x1f80, 0x3fc0, 0x3fc0, 0x3fc0, 0x1f80, 0x1cf38, 0x3e67c, 0x7f6fe, 0x7fffe, 0x7f6fe, 0x3e67c, 0x18618, 0x700, 0xf00, 0x1f80, 0x3fc0, 0x0),
            intArrayOf(0x0, 0xe00, 0x1f00, 0x3f80, 0x3f80, 0x3f80, 0x3f80, 0x1f80, 0x1cf38, 0x7e6fc, 0x7f6fe, 0x7fffe, 0x7f6fe, 0x7e67c, 0x8610, 0xf00, 0xf00, 0x3f80, 0x3fc0, 0x0),
        ),
        'S' to listOf(
            intArrayOf(0x0, 0xf00, 0x1f80, 0x3fc0, 0xffe0, 0x1fff8, 0x3fff8, 0x3fffc, 0x7fffe, 0x7fffe, 0x7fffe, 0x3fffc, 0x3fffc, 0x1fff8, 0x4640, 0xe00, 0xf00, 0x1f80, 0x3fc0, 0x0),
            intArrayOf(0x0, 0x600, 0x1f00, 0x3fc0, 0x7fe0, 0xfff0, 0x1fff8, 0x3fffc, 0x3fffc, 0x7fffc, 0x7fffc, 0x7fffc, 0x3fffc, 0x3fff8, 0xf7f0, 0x600, 0xf00, 0xf00, 0x3f80, 0x0),
            intArrayOf(0x0, 0x600, 0x1f00, 0x3fc0, 0x7fe0, 0xfff0, 0x1fff8, 0x3fffc, 0x7fffc, 0x7fffe, 0x7fffe, 0x7fffe, 0x7fffc, 0x3fffc, 0x1fff0, 0x600, 0xf00, 0xf00, 0x1f80, 0x0),
        ),
    )

    fun read(bitmap: Bitmap, tokens: List<OcrToken>): Board? {
        val w = bitmap.width.toFloat(); val h = bitmap.height.toFloat()
        if (w < 300f || h < 650f) return null
        val cols = MutableList(7) { mutableListOf<Seen>() }
        val top = h * .326f
        val bottom = h * .79f
        for (t in tokens) {
            val cy = (t.top + t.bottom) / 2f
            if (cy < top || cy > bottom) continue
            val rank = parseRank(t.text) ?: continue
            val cx = (t.left + t.right) / 2f
            val col = centers.indices.minByOrNull { kotlin.math.abs(cx - centers[it] * w) } ?: continue
            if (kotlin.math.abs(cx - centers[col] * w) > w * .050f) continue
            val cardLeft = centers[col] * w - w * .064f
            if (t.left > cardLeft + w * .070f) continue // ignore a suit glyph misread as a rank
            val color = sampleColor(bitmap, cardLeft, t.top.toFloat() - h * .004f, w) ?: continue
            val y = (t.top + t.bottom) / 2f
            cols[col].add(Seen(Card(rank, '?', color, false), centers[col] * w, y, cardLeft, t.top.toFloat() - h * .004f, col))
        }
        for (c in cols) c.sortBy { it.y }
        // OCR may duplicate a rank at the same physical card; collapse near-identical boxes.
        for (i in cols.indices) {
            val clean = mutableListOf<Seen>()
            for (card in cols[i]) if (clean.isEmpty() || card.y - clean.last().y > h * .018f) clean.add(card)
            cols[i] = clean
        }
        // A real face-up tableau is always a descending alternating run. Reject incomplete
        // OCR reads rather than dragging from a guessed card position.
        for (c in cols) if (c.isNotEmpty() && !KlondikeRules.isValidRun(c.map { it.card })) return null
        // The exposed top card has its large central suit icon visible; use it to confirm the suit.
        for (c in cols) if (c.isNotEmpty()) {
            val i = c.lastIndex; val topCard = c[i]
            val suit = classifyLargeSuit(bitmap, topCard.cardLeft, topCard.cardTop, w, topCard.card.color)
            if (suit != null) c[i] = topCard.copy(card = topCard.card.copy(suit = suit, suitKnown = true))
        }
        val visibleCards = mutableListOf<Card>()
        cols.forEach { c -> c.forEach { visibleCards.add(it.card) } }
        val knownVisible = visibleCards.filter { it.suitKnown }
        if (knownVisible.distinct().size != knownVisible.size) return null

        // An empty tableau column is legal. If a column visually contains a white face card
        // or a red-backed hidden card but OCR did not decode it, reject this frame as uncertain.
        for (i in cols.indices) if (cols[i].isEmpty() && columnLooksOccupied(bitmap, centers[i] * w, h)) return null
        if (cols.none { it.isNotEmpty() }) return null

        val foundations = linkedMapOf('H' to 0, 'D' to 0, 'C' to 0, 'S' to 0)
        val foundationSlots = linkedMapOf<Char, Int>()
        val wasteTokens = mutableListOf<OcrToken>()
        for (t in tokens) {
            val cy = (t.top + t.bottom) / 2f
            if (cy !in (h * .225f)..(h * .315f)) continue
            val rank = parseRank(t.text) ?: continue
            val cx = (t.left + t.right) / 2f
            if (cx < w * .56f) {
                val idx = centers.take(4).indices.minByOrNull { kotlin.math.abs(cx - centers[it] * w) } ?: continue
                val slotLeft = centers[idx] * w - w * .064f
                if (kotlin.math.abs(cx - centers[idx] * w) < w * .055f && t.left <= slotLeft + w * .070f) {
                    val cardTop = t.top.toFloat() - h * .004f
                    val color = sampleColor(bitmap, slotLeft, cardTop, w) ?: continue
                    val suit = classifyLargeSuit(bitmap, slotLeft, cardTop, w, color) ?: continue
                    foundations[suit] = max(foundations[suit] ?: 0, rank)
                    foundationSlots[suit] = idx
                }
            } else if (cx in (w * .58f)..(w * .86f) && t.left < w * .765f) {
                wasteTokens.add(t)
            }
        }
        var waste: Seen? = null
        val wasteToken = wasteTokens.maxByOrNull { (it.left + it.right) / 2f }
        if (wasteToken != null) {
            val left = wasteToken.left - w * .010f
            val cardTop = wasteToken.top.toFloat() - h * .004f
            val color = sampleColor(bitmap, left, cardTop, w) ?: return null
            val suit = classifyLargeSuit(bitmap, left, cardTop, w, color)
            val rank = parseRank(wasteToken.text) ?: return null
            waste = Seen(Card(rank, suit ?: '?', color, suit != null), (wasteToken.left + wasteToken.right)/2f,
                (wasteToken.top + wasteToken.bottom)/2f, left, cardTop)
        }
        val hidden = cols.map { c ->
            if (c.isEmpty()) 0 else {
                val firstY = c.first().y
                max(0, ((firstY - h * .3485f) / (h * .0105f)).roundToInt().coerceAtMost(6))
            }
        }
        val usedFoundationSlots = foundationSlots.values.toSet()
        for (slot in 0..3) if (slot !in usedFoundationSlots && foundationLooksOccupied(bitmap, centers[slot] * w, h)) return null
        for ((suit, rank) in foundations) if (rank > 0) {
            if (visibleCards.any { it.suit == suit && it.rank == rank }) return null
        }
        waste?.let { if (visibleCards.contains(it.card)) return null }
        if (waste == null && wasteLooksOccupied(bitmap, w, h)) return null
        val stock = redBackPresent(bitmap, w * .855f, h * .242f, w * .985f, h * .323f)
        val sig = buildString {
            cols.forEach { col -> append(col.joinToString(".") { "${it.card.rank}${it.card.suit}${it.card.color}${it.card.suitKnown}" }); append('|') }
            append(hidden.joinToString(",")); append('|')
            append(foundations.entries.joinToString("") { "${it.key}${it.value}" }); append('|')
            append(foundationSlots.entries.joinToString("") { "${it.key}${it.value}" }); append('|')
            append(waste?.let { "${it.card.rank}${it.card.suit}${it.card.color}${it.card.suitKnown}" } ?: "-"); append('|'); append(stock)
        }
        return Board(cols, hidden, foundations, foundationSlots, waste, stock, sig)
    }

    internal fun parseRank(text: String): Int? {
        // ML Kit may attach a tiny suit mark or punctuation to the rank element.
        // Strip non-alphanumerics, then require the entire remaining token to be a rank;
        // never accept a digit embedded in a score, timer, or unrelated word.
        val token = text.uppercase().filter { it.isLetterOrDigit() }
        val match = rankRegex.matchEntire(token) ?: return null
        val rank = match.groupValues[1]
        return when (rank) { "A" -> 1; "J" -> 11; "Q" -> 12; "K" -> 13; else -> rank.toIntOrNull() }
    }

    private fun sampleColor(b: Bitmap, leftF: Float, topF: Float, width: Float): Int? {
        val scale = width / 674f
        val l=(leftF+48f*scale).toInt().coerceIn(0,b.width-1); val t=(topF+2f*scale).toInt().coerceIn(0,b.height-1)
        val r=min(b.width,l+(36f*scale).toInt().coerceAtLeast(12)); val bot=min(b.height,t+(29f*scale).toInt().coerceAtLeast(12))
        var red=0; var black=0
        for(y in t until bot) for(x in l until r){
            val p=b.getPixel(x,y); val rr=(p shr 16) and 255; val gg=(p shr 8) and 255; val bb=p and 255
            val hi=max(rr,max(gg,bb)); val lo=min(rr,min(gg,bb))
            if(rr>gg*1.25 && rr>bb*1.20 && rr>100) red++
            else if(hi<155 && hi-lo<65) black++
        }
        return when { red > black && red >= 5 -> 1; black > red && black >= 5 -> 0; else -> null }
    }

    private fun classifyLargeSuit(b: Bitmap, cardLeftF: Float, cardTopF: Float, width: Float, color: Int): Char? {
        val scale = width / 674f
        val candidates = if (color == 1) listOf('H', 'D') else listOf('C', 'S')
        val bestBySuit = mutableMapOf<Char, Float>()
        // The game's exposed icon can sit at slightly different vertical offsets depending on
        // the column fan. Search several windows below the rank corner, then keep the strongest match.
        for (offset in intArrayOf(34, 42, 50, 58, 66)) {
            val l = (cardLeftF + 15f * scale).toInt().coerceIn(0, b.width - 1)
            val t = (cardTopF + offset * scale).toInt().coerceIn(0, b.height - 1)
            val r = min(b.width, l + (60f * scale).toInt().coerceAtLeast(20))
            val bot = min(b.height, t + (50f * scale).toInt().coerceAtLeast(20))
            if (r - l < 10 || bot - t < 10) continue
            val foreground = Array(bot - t) { BooleanArray(r - l) }
            var minX = r; var minY = bot; var maxX = -1; var maxY = -1
            for (y in t until bot) for (x in l until r) {
                val p = b.getPixel(x, y)
                val rr = (p shr 16) and 255; val gg = (p shr 8) and 255; val bb = p and 255
                val hi = max(rr, max(gg, bb)); val lo = min(rr, min(gg, bb))
                val ink = (rr > gg * 1.25 && rr > bb * 1.20 && rr > 100) || (hi < 155 && hi - lo < 65)
                foreground[y - t][x - l] = ink
                if (ink) { minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y) }
            }
            if (maxX <= minX || maxY <= minY) continue
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            val side = max(bw, bh).toFloat() + 4f
            val padX = (side - bw) / 2f; val padY = (side - bh) / 2f
            val input = Array(20) { BooleanArray(20) }
            for (yy in 0 until 20) for (xx in 0 until 20) {
                val sx = minX + (((xx + .5f) / 20f * side - padX).toInt()).coerceIn(0, bw - 1)
                val sy = minY + (((yy + .5f) / 20f * side - padY).toInt()).coerceIn(0, bh - 1)
                input[yy][xx] = foreground[sy - t][sx - l]
            }
            for (suit in candidates) {
                var suitBest = bestBySuit[suit] ?: 0f
                for (rows in largeTemplates.getValue(suit)) {
                    var intersection = 0; var union = 0
                    for (yy in 0 until 20) for (xx in 0 until 20) {
                        val a = input[yy][xx]; val bit = (rows[yy] ushr (19 - xx)) and 1 != 0
                        if (a && bit) intersection++
                        if (a || bit) union++
                    }
                    val score = if (union == 0) 0f else intersection.toFloat() / union
                    if (score > suitBest) suitBest = score
                }
                bestBySuit[suit] = suitBest
            }
        }
        val ranked = bestBySuit.entries.sortedByDescending { it.value }
        val best = ranked.firstOrNull() ?: return null
        val second = ranked.getOrNull(1)?.value ?: 0f
        // High confidence only: an uncertain suit is left unknown and cannot be sent to a foundation.
        return if (best.value >= .68f && best.value - second >= .07f) best.key else null
    }

    private fun wasteLooksOccupied(b: Bitmap, w: Float, h: Float): Boolean {
        val x0=(w*.60f).toInt().coerceIn(0,b.width-1); val x1=(w*.84f).toInt().coerceIn(x0+1,b.width)
        val y0=(h*.245f).toInt().coerceIn(0,b.height-1); val y1=(h*.32f).toInt().coerceIn(y0+1,b.height)
        var white=0; var n=0
        for(y in y0 until y1 step 3) for(x in x0 until x1 step 3){
            val p=b.getPixel(x,y); val r=(p shr 16) and 255; val g=(p shr 8) and 255; val bl=p and 255
            if(r>205 && g>205 && bl>195) white++; n++
        }
        return n>0 && white.toFloat()/n>.12f
    }

    private fun foundationLooksOccupied(b: Bitmap, center: Float, h: Float): Boolean {
        val x0=(center-b.width*.025f).toInt().coerceIn(0,b.width-1)
        val x1=(center+b.width*.025f).toInt().coerceIn(x0+1,b.width)
        val y0=(h*.255f).toInt().coerceIn(0,b.height-1)
        val y1=(h*.305f).toInt().coerceIn(y0+1,b.height)
        var white=0; var n=0
        for(y in y0 until y1 step 3) for(x in x0 until x1 step 3){
            val p=b.getPixel(x,y); val r=(p shr 16) and 255; val g=(p shr 8) and 255; val bl=p and 255
            if(r>205 && g>205 && bl>195) white++; n++
        }
        return n>0 && white.toFloat()/n>.18f
    }

    private fun columnLooksOccupied(b: Bitmap, center: Float, h: Float): Boolean {
        val x = center.toInt().coerceIn(0, b.width - 1)
        val y0 = (h * .335f).toInt().coerceIn(0, b.height - 1)
        val y1 = (h * .78f).toInt().coerceIn(y0 + 1, b.height)
        var white = 0; var red = 0; var n = 0
        for (y in y0 until y1 step 5) {
            val p = b.getPixel(x, y); val r=(p shr 16) and 255; val g=(p shr 8) and 255; val bl=p and 255
            if (r > 205 && g > 205 && bl > 195) white++
            if (r > g * 1.25 && r > bl * 1.2 && r > 90) red++
            n++
        }
        return white > n * .12 || red > n * .10
    }

    private fun redBackPresent(b: Bitmap, l: Float, t: Float, r: Float, bot: Float): Boolean {
        val x0=l.toInt().coerceIn(0,b.width-1); val x1=r.toInt().coerceIn(x0+1,b.width)
        val y0=t.toInt().coerceIn(0,b.height-1); val y1=bot.toInt().coerceIn(y0+1,b.height)
        var red=0; var total=0
        val stepX=max(1,(x1-x0)/35); val stepY=max(1,(y1-y0)/35)
        for (y in y0 until y1 step stepY) for (x in x0 until x1 step stepX) {
            val p=b.getPixel(x,y); val rr=(p shr 16) and 255; val gg=(p shr 8) and 255; val bb=p and 255
            if (rr > gg*1.28 && rr > bb*1.20 && rr > 95) red++
            total++
        }
        return total > 0 && red.toFloat()/total > .10f
    }
}
