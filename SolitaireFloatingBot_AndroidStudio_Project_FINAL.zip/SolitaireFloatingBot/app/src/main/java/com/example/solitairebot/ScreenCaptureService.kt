package com.example.solitairebot

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    companion object { const val EXTRA_RESULT_CODE = "result_code"; const val EXTRA_DATA = "result_data"; const val ACTION_OCR = "com.example.solitairebot.OCR" }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var busy = false
    private var lastFrameAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = Notification.Builder(this, "capture")
            .setContentTitle("بوت سوليتير")
            .setContentText("التقاط الشاشة وتحليل الأوراق محلياً")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(41, notification)
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, ActivityResult.RESULT_CANCELED) ?: ActivityResult.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (code != ActivityResult.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels; val height = metrics.heightPixels; val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (busy || now - lastFrameAt < 350L) return@setOnImageAvailableListener
                lastFrameAt = now
                busy = true
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride; val rowStride = plane.rowStride
                val paddedWidth = rowStride / pixelStride
                val raw = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
                raw.copyPixelsFromBuffer(buffer)
                val bitmap = Bitmap.createBitmap(raw, 0, 0, width, height)
                raw.recycle()
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        val tokens = ArrayList<OcrToken>()
                        // Use individual ML Kit elements, not whole lines. Several waste cards
                        // share one horizontal baseline; line-level OCR merges their ranks and
                        // assigns the combined box to only one column.
                        for (block in result.textBlocks) for (line in block.lines) for (element in line.elements) {
                            val r = element.boundingBox ?: continue
                            tokens.add(OcrToken(element.text, r.left, r.top, r.right, r.bottom))
                        }
                        SolitaireBrain.onFrame(width, height, bitmap, tokens)
                    }
                    .addOnCompleteListener { bitmap.recycle(); busy = false }
            } catch (_: Exception) { busy = false } finally { image.close() }
        }, null)
        display = projection?.createVirtualDisplay("SolitaireCapture", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("capture", "التقاط الشاشة", NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onDestroy() { display?.release(); reader?.close(); projection?.stop(); recognizer.close(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

private object ActivityResult { const val RESULT_OK = -1; const val RESULT_CANCELED = 0 }
