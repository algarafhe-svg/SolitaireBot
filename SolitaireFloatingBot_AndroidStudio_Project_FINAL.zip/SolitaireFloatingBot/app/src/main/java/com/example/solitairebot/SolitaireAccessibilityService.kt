package com.example.solitairebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Android accessibility is used only as a local gesture executor. */
class SolitaireAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: SolitaireAccessibilityService? = null }
    @Volatile private var active = false
    @Volatile private var paused = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { pauseAutoPlay() }

    fun startAutoPlay() { active = true; paused = false }
    fun pauseAutoPlay() { paused = true }
    fun resumeAutoPlay() { if (active) paused = false }
    fun stopAutoPlay() { active = false; paused = false }

    fun dragCoordinates(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long = 430): Boolean {
        if (!active || paused) return false
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        return dispatchGesture(gesture, null, null)
    }

    fun tapCoordinates(x: Float, y: Float): Boolean {
        if (!active || paused) return false
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90)).build()
        return dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() { stopAutoPlay(); instance = null; super.onDestroy() }
}

data class Card(val rank: Int, val suit: Char, val color: Int, val suitKnown: Boolean = true)
data class OcrToken(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)
