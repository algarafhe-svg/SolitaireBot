package com.example.solitairebot

/** Pure Klondike rules used by the planner; ranks are A=1 through K=13. */
internal object KlondikeRules {
    fun isValidRun(cards: List<Card>): Boolean = cards.isNotEmpty() &&
        cards.zipWithNext().all { (lower, upper) -> lower.rank == upper.rank + 1 && lower.color != upper.color }

    fun canPlaceOnTableau(card: Card, target: Card?): Boolean =
        if (target == null) card.rank == 13 else target.rank == card.rank + 1 && target.color != card.color

    fun canPlaceOnFoundation(card: Card, foundationRank: Int): Boolean = card.rank == foundationRank + 1

    /** Do not send a high card to foundations if the opposite color foundations are far behind. */
    fun isSafeFoundationAdvance(card: Card, foundations: Map<Char, Int>): Boolean {
        if (card.rank <= 2) return true
        val opposite = if (card.color == 1) listOf('C', 'S') else listOf('H', 'D')
        return opposite.minOf { foundations[it] ?: 0 } >= card.rank - 2
    }
}
