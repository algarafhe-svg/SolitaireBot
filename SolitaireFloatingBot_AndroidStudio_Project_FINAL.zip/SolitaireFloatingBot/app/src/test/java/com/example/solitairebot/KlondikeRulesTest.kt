package com.example.solitairebot

import org.junit.Assert.*
import org.junit.Test

class KlondikeRulesTest {
    private fun c(rank: Int, suit: Char) = Card(rank, suit, if (suit == 'H' || suit == 'D') 1 else 0)

    @Test fun alternatingDescendingRunIsLegal() {
        assertTrue(KlondikeRules.isValidRun(listOf(c(11,'D'), c(10,'S'), c(9,'D'))))
    }

    @Test fun sameColorOrWrongOrderRunIsIllegal() {
        assertFalse(KlondikeRules.isValidRun(listOf(c(11,'D'), c(10,'H'))))
        assertFalse(KlondikeRules.isValidRun(listOf(c(10,'S'), c(11,'D'))))
    }

    @Test fun onlyKingCanEnterEmptyColumn() {
        assertTrue(KlondikeRules.canPlaceOnTableau(c(13,'S'), null))
        assertFalse(KlondikeRules.canPlaceOnTableau(c(12,'H'), null))
    }

    @Test fun tableauRequiresOneLowerRankAndOppositeColor() {
        assertTrue(KlondikeRules.canPlaceOnTableau(c(9,'H'), c(10,'S')))
        assertFalse(KlondikeRules.canPlaceOnTableau(c(9,'H'), c(10,'D')))
        assertFalse(KlondikeRules.canPlaceOnTableau(c(8,'H'), c(10,'S')))
    }

    @Test fun foundationMustAdvanceSameSuitByOne() {
        assertTrue(KlondikeRules.canPlaceOnFoundation(c(4,'C'), 3))
        assertFalse(KlondikeRules.canPlaceOnFoundation(c(5,'C'), 3))
    }

    @Test fun rankParserAcceptsCardLabelsAndSuitGlyphs() {
        assertEquals(1, JawakerVision.parseRank("A"))
        assertEquals(10, JawakerVision.parseRank("10"))
        assertEquals(12, JawakerVision.parseRank("Q♦"))
        assertEquals(13, JawakerVision.parseRank("K S"))
    }

    @Test fun rankParserRejectsScoresAndClockText() {
        assertNull(JawakerVision.parseRank("550"))
        assertNull(JawakerVision.parseRank("03:33"))
        assertNull(JawakerVision.parseRank("632"))
        assertNull(JawakerVision.parseRank("SCORE"))
    }

    @Test fun highFoundationAdvanceWaitsForOppositeColorSupport() {
        assertFalse(KlondikeRules.isSafeFoundationAdvance(c(8,'H'), mapOf('C' to 2, 'S' to 3)))
        assertTrue(KlondikeRules.isSafeFoundationAdvance(c(8,'H'), mapOf('C' to 6, 'S' to 7)))
        assertTrue(KlondikeRules.isSafeFoundationAdvance(c(2,'H'), emptyMap()))
    }
}
