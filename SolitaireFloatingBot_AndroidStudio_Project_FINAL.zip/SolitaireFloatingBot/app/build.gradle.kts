plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.solitairebot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.solitairebot"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    testImplementation("junit:junit:4.13.2")
}
