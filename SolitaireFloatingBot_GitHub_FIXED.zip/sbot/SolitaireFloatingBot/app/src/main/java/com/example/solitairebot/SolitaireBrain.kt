package com.example.solitairebot

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlin.math.abs

/** Local OCR-based Klondike planner. It refuses to move when rank/suit recognition is ambiguous. */
object SolitaireBrain {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var enabled = false
    @Volatile private var paused = false
    private var lastSignature = ""
    private var lastMoveAt = 0L
    private var lastContext: Context? = null
    private val rankPattern = Regex("(?i)(10|[2-9]|A|J|Q|K)")
    private val suitPattern = Regex("[♠♥♦♣]")

    fun start(context: Context) { lastContext=context.applicationContext; enabled=true; paused=false; lastSignature="" }
    fun pause() { paused=true }
    fun resume() { if (enabled) paused=false }
    fun stop() { enabled=false; paused=false; handler.removeCallbacksAndMessages(null) }

    fun onFrame(width: Int, height: Int, tokens: List<OcrToken>, context: Context) {
        if (!enabled || paused) return
        val service = SolitaireAccessibilityService.instance ?: return
        val cards = tokens.mapNotNull { token -> parse(token)?.let { it.copy(x=(token.left+token.right)/2f, y=(token.top+token.bottom)/2f) } }
        val tableau = cards.filter { it.y > height*0.32f && it.y < height*0.80f && it.x > width*0.005f && it.x < width*0.995f }
        val cols = (0..6).map { col -> tableau.filter { abs(it.x - (width*(0.075f + col*0.14f))) < width*0.065f }.sortedBy { it.y } }
        val signature = cols.joinToString("|") { c -> c.joinToString(",") { "${it.rank}${it.suit}" } }
        if (signature.isBlank() || signature == lastSignature) return
        lastSignature = signature
        // Try foundations first, then legal whole-stack tableau moves. Source coordinates are the
        // visible rank/suit label of the first card in the moved sequence.
        val move = findTableauMove(cols, width, height)
        if (move != null && System.currentTimeMillis()-lastMoveAt > 1300) {
            service.dragCoordinates(move.sx, move.sy, move.dx, move.dy, 500); lastMoveAt=System.currentTimeMillis(); return
        }
        // No safe move inferred. We intentionally do not tap stock blindly: stock exhaustion and
        // waste recycling differ by game settings, so a blind tap can corrupt the detected state.
        Log.d("SolitaireBrain", "No unambiguous legal move; waiting for next frame")
    }

    private fun findTableauMove(cols: List<List<SeenCard>>, w: Int, h: Int): Move? {
        for (src in cols.indices) {
            val cards = cols[src]
            if (cards.isEmpty()) continue
            for (start in cards.indices) {
                val stack = cards.drop(start)
                if (stack.isEmpty() || !validSequence(stack)) continue
                val bottom = stack.first()
                for (dst in cols.indices) {
                    if (dst == src) continue
                    val target = cols[dst].lastOrNull() ?: continue // Empty-column K rule is not inferred safely yet.
                    if (target.rank == bottom.rank+1 && target.color != bottom.color) {
                        // Only move when it exposes a hidden card or places a longer sequence.
                        if (start > 0 || stack.size > 1) {
                            return Move(bottom.x, bottom.y, target.x, target.y)
                        }
                    }
                }
            }
        }
        return null
    }
    private fun validSequence(cards: List<SeenCard>): Boolean = cards.zipWithNext().all { (a,b) -> a.rank == b.rank+1 && a.color != b.color }
    private fun parse(t: OcrToken): SeenCard? {
        val s=t.text.uppercase().replace(" ", "")
        val rankText=rankPattern.find(s)?.value ?: return null
        val suit=when { s.contains('♠') -> 'S'; s.contains('♥') -> 'H'; s.contains('♦') -> 'D'; s.contains('♣') -> 'C'; else -> return null }
        val rank=when(rankText.uppercase()) { "A"->1; "J"->11; "Q"->12; "K"->13; else->rankText.toIntOrNull() ?: return null }
        return SeenCard(rank,suit,if(suit=='H'||suit=='D') 1 else 0,0f,0f)
    }
    private data class Move(val sx:Float,val sy:Float,val dx:Float,val dy:Float)
    private data class SeenCard(val rank:Int,val suit:Char,val color:Int,val x:Float,val y:Float)
}
