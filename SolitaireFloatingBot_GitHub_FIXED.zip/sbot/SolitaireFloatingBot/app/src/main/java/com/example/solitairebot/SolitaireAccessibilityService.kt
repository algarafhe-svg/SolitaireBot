package com.example.solitairebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Accessibility-driven starter engine.
 * It can only understand cards exposed as text/contentDescription by the target game.
 * Games drawn on a Canvas without accessible card labels require a game-specific vision adapter.
 */
class SolitaireAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: SolitaireAccessibilityService? = null }
    private val handler = Handler(Looper.getMainLooper())
    private val active = AtomicBoolean(false)
    private val paused = AtomicBoolean(false)
    private var lastActionAt = 0L

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // The next decision is scheduled by the engine loop; events are intentionally not spammed.
    }
    override fun onInterrupt() { pauseAutoPlay() }

    fun startAutoPlay() {
        active.set(true); paused.set(false)
        scheduleStep(700)
    }
    fun pauseAutoPlay() { paused.set(true) }
    fun resumeAutoPlay() { if (active.get()) { paused.set(false); scheduleStep(250) } }
    fun stopAutoPlay() {
        active.set(false); paused.set(false); handler.removeCallbacksAndMessages(null)
    }

    private fun scheduleStep(delay: Long) {
        handler.postDelayed({
            if (!active.get() || paused.get()) return@postDelayed
            val root = rootInActiveWindow
            if (root != null) {
                val cards = mutableListOf<CardNode>()
                collectCards(root, cards)
                val move = SolitaireHeuristic.choose(cards)
                if (move != null) {
                    performDrag(move.from, move.to)
                    lastActionAt = System.currentTimeMillis()
                }
                root.recycle()
            }
            if (active.get() && !paused.get()) scheduleStep(1100)
        }, delay)
    }

    private fun collectCards(node: AccessibilityNodeInfo, out: MutableList<CardNode>) {
        val label = (node.contentDescription?.toString() ?: node.text?.toString() ?: "").trim()
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        val card = SolitaireHeuristic.parseCard(label)
        if (card != null && bounds.width() > 20 && bounds.height() > 25) {
            out.add(CardNode(card, bounds))
        }
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            collectCards(child, out)
            child.recycle()
        }
    }

    fun dragCoordinates(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long = 420) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        dispatchGesture(gesture, null, null)
    }

    fun tapCoordinates(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(gesture, null, null)
    }

    private fun performDrag(from: Rect, to: Rect) {
        val path = Path().apply {
            moveTo(from.exactCenterX(), from.exactCenterY())
            lineTo(to.exactCenterX(), to.exactCenterY())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 420))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        stopAutoPlay()
        instance = null
        super.onDestroy()
    }
}

data class Card(val rank: Int, val suit: Char, val color: Int)
data class CardNode(val card: Card, val bounds: Rect)
data class PlannedMove(val from: Rect, val to: Rect)

/**
 * Conservative baseline planner. It detects common accessible card labels (e.g. "AS",
 * "10H", "Q♠", "King of Clubs"). It moves a card only when a visible destination
 * is inferable from the exposed card labels. This is a starter, not a full Klondike solver.
 */
object SolitaireHeuristic {
    private val rankMap = mapOf("A" to 1, "J" to 11, "Q" to 12, "K" to 13)
    fun parseCard(raw: String): Card? {
        val s = raw.uppercase().replace(" " , "")
        val rankToken = Regex("^(10|[2-9]|[AJQK])").find(s)?.value ?: return null
        val suitToken = when {
            s.contains("♠") || s.endsWith("S") || s.contains("SPADE") -> 'S'
            s.contains("♥") || s.endsWith("H") || s.contains("HEART") -> 'H'
            s.contains("♦") || s.endsWith("D") || s.contains("DIAMOND") -> 'D'
            s.contains("♣") || s.endsWith("C") || s.contains("CLUB") -> 'C'
            else -> return null
        }
        val rank = rankMap[rankToken] ?: rankToken.toIntOrNull() ?: return null
        return Card(rank, suitToken, if (suitToken == 'H' || suitToken == 'D') 1 else 0)
    }

    fun choose(nodes: List<CardNode>): PlannedMove? {
        if (nodes.size < 2) return null
        // Avoid speculative moves: this generic version has no reliable tableau/stock/foundation
        // region map. A game-specific adapter must provide those semantics before moving.
        return null
    }
}
