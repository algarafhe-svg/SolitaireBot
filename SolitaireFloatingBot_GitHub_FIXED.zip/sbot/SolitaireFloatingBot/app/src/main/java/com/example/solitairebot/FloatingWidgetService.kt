package com.example.solitairebot

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class FloatingWidgetService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var paused = false
    override fun onCreate() { super.onCreate(); if (!Settings.canDrawOverlays(this)) { stopSelf(); return }; wm = getSystemService(WINDOW_SERVICE) as WindowManager; createPanel() }
    private fun createPanel() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 6, 8, 6); setBackgroundResource(R.drawable.floating_panel) }
        val start = Button(this).apply { text = "Start" }; val pause = Button(this).apply { text = "Pause" }; val stop = Button(this).apply { text = "Stop" }
        layout.addView(start); layout.addView(pause); layout.addView(stop)
        start.setOnClickListener {
            if (SolitaireAccessibilityService.instance == null) Toast.makeText(this, "فعّل خدمة إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
            else { paused = false; SolitaireBrain.start(this); pause.text = "Pause"; Toast.makeText(this, "بدأ تحليل اللوحة", Toast.LENGTH_SHORT).show() }
        }
        pause.setOnClickListener { if (!paused) { paused = true; SolitaireBrain.pause(); pause.text = "Resume" } else { paused = false; SolitaireBrain.resume(); pause.text = "Pause" } }
        stop.setOnClickListener { SolitaireBrain.stop(); stopService(Intent(this, ScreenCaptureService::class.java)); stopSelf() }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 8; y = 170 }
        layout.setOnTouchListener(object : View.OnTouchListener { var sx=0f; var sy=0f; var ox=0; var oy=0; override fun onTouch(v: View, e: MotionEvent): Boolean { when(e.action) { MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; return false }; MotionEvent.ACTION_MOVE -> { params.x=ox+(sx-e.rawX).toInt(); params.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(layout,params); return true } }; return false } })
        panel=layout; wm.addView(layout,params)
    }
    override fun onDestroy() { SolitaireBrain.stop(); panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
