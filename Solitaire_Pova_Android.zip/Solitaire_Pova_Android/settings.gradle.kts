dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECTS_DKPE)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Solitaire_Pova_Android"