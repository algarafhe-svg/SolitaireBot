package com.jawaker.solitaire.service

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.WindowManager
import android.widget.Toast

/**
 * Floating service that manages the bot overlay and state.
 * Can be extended to show a floating UI over other apps.
 */
class FloatingBotService : Service() {

    private var mFloatingView: View? = null
    private var mParams: WindowManager.LayoutParams? = null
    private var windowManager: WindowManager? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as? WindowManager
        // Initialize floating view if needed
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Handle starting the bot
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    fun showFloatingOverlay() {
        if (mFloatingView != null) return

        val inflater = LayoutInflater.from(this)
        mFloatingView = inflater.inflate(R.layout.overlay_bot, null)

        mParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        mParams!!.gravity = Gravity.BOTTOM or Gravity.START
        mParams!!.x = 0f
        mParams!!.y = 0f
        mParams!!.width = WindowManager.LayoutParams.MATCH_PARENT
        mParams!!.height = WindowManager.LayoutParams.WRAP_CONTENT
        mParams!!.windowAnimations = 0

        windowManager!!.addView(mFloatingView, mParams)
    }

    fun hideFloatingOverlay() {
        mFloatingView?.let { view ->
            windowManager!!.removeView(view)
            mFloatingView = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hideFloatingOverlay()
    }
}