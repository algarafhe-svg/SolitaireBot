package com.jawaker.solitaire.service

import android.graphics.Bitmap
import android.graphics.Rect
import com.jawaker.solitaire.model.Card
import com.jawaker.solitaire.model.FoundationSlot
import com.jawaker.solitaire.model.GameState
import com.jawaker.solitaire.model.Rank
import com.jawaker.solitaire.model.Suit
import com.jawaker.solitaire.model.TableauColumn

/**
 * Engine that processes screen capture data and provides structured game state
 * for the auto-solver to make decisions.
 * ALL COORDINATES are relative and will be scaled based on actual screen dimensions.
 * No hardcoded emulator 900x1600 pixel values.
 */
class CardVisionEngine {

    /**
     * Analyze screen bitmap and extract structured game state.
     * Bitmap dimensions are used to calculate all coordinates proportionally.
     */
    fun analyzeScreen(bitmap: Bitmap, screenWidth: Int, screenHeight: Int): GameState {
        val gameState = GameState()

        // Calculate proportional regions based on actual screen size
        val foundationsY = screenHeight * 22 / 100  // 22% from top
        val foundationsHeight = screenHeight / 8
        val foundationSlotWidth = screenWidth * 44 / 100 / 4  // 4 slots across ~44% width
        val foundationSlotGap = foundationSlotWidth * 2 / 4

        val tableauStartY = screenHeight * 33 / 100  // 33% from top
        val tableauEndY = screenHeight * 84 / 100    // 84% from top (bottom of tableau)
        val columnWidth = screenWidth / 7

        // 1. Detect Foundations (4 slots)
        detectFoundations(gameState, screenWidth, foundationsY, foundationSlotWidth, foundationSlotGap, foundationsHeight)

        // 2. Detect Stock Pile (top-right area: ~87% width, 22% height)
        detectStockPile(gameState, screenWidth, screenHeight)

        // 3. Detect Waste Pile (X=62%-78%, Y=22%)
        detectWastePile(gameState, screenWidth, screenHeight, tableauStartY)

        // 4. Detect Tableau Columns 1-7
        detectTableauColumns(gameState, screenWidth, screenHeight, columnWidth, tableauStartY, tableauEndY)

        return gameState
    }

    /**
     * Detect Foundations area: 4 slots positioned proportionally.
     */
    private fun detectFoundations(
        gameState: GameState,
        screenWidth: Int,
        foundationsY: Float,
        foundationSlotWidth: Float,
        foundationSlotGap: Float,
        foundationsHeight: Float
    ) {
        gameState.foundationPiles = emptyList()

        val slots = mutableListOf<FoundationSlot>()

        for (slotIndex in 0 until 4) {
            // Calculate X position for each foundation slot
            val slotX = (screenWidth * 12 / 100) + (slotIndex * (foundationSlotWidth + foundationSlotGap)) + (foundationSlotWidth / 2)
            val slotY = foundationsY + (foundationsHeight / 2)

            // Sample region around the foundation slot center: ±20% of slot width, ±15% of height
            val regionLeft = Math.max(0f, slotX - foundationSlotWidth / 3f).coerceAtMost(screenWidth.toFloat())
            val regionRight = Math.min(screenWidth.toFloat(), slotX + foundationSlotWidth / 3f).coerceAtLeast(0f)
            val regionTop = Math.max(0f, slotY - foundationsHeight / 4f).coerceAtMost(screenHeight.toFloat())
            val regionBottom = Math.min(screenHeight.toFloat(), slotY + foundationsHeight / 4f).coerceAtLeast(0f)

            val region = Rect(
                regionLeft.toInt(), regionTop.toInt(),
                regionRight.toInt(), regionBottom.toInt()
            )
            val cardsInSlot = analyzeColorRegionForCards(bitmap = null, region, screenWidth, screenHeight, "foundation_$slotIndex")

            // Determine suit based on position order: Hearts, Diamonds, Spades, Clubs
            val suit = when (slotIndex) {
                0 -> Suit.HEARTS
                1 -> Suit.DIAMONDS
                2 -> Suit.SPADES
                3 -> Suit.CLUBS
                else -> Suit.HEARTS
            }

            slots.add(FoundationSlot(suit = suit, cards = cardsInSlot))
        }

        gameState.foundationPiles = slots
    }

    /**
     * Detect Stock Pile - top right area.
     */
    private fun detectStockPile(gameState: GameState, screenWidth: Int, screenHeight: Int) {
        val stockScreenX = screenWidth * 87 / 100  // 87% from left
        val stockScreenY = screenHeight * 22 / 100  // 22% from top

        val regionLeft = Math.max(0f, stockScreenX - screenWidth / 10f).coerceAtMost(screenWidth.toFloat())
        val regionRight = Math.min(screenWidth.toFloat(), stockScreenX + screenWidth / 10f).coerceAtLeast(0f)
        val regionTop = Math.max(0f, stockScreenY - screenHeight / 10f).coerceAtMost(screenHeight.toFloat())
        val regionBottom = Math.min(screenHeight.toFloat(), stockScreenY + screenHeight / 10f).coerceAtLeast(0f)

        val region = Rect(regionLeft.toInt(), regionTop.toInt(), regionRight.toInt(), regionBottom.toInt())
        val cardsInRegion = analyzeColorRegionForCards(bitmap = null, region, screenWidth, screenHeight, "stock")

        gameState.stockPileCards = cardsInRegion
    }

    /**
     * Detect Waste Pile - left of stock, X=62%-78%, Y=22%.
     */
    private fun detectWastePile(
        gameState: GameState,
        screenWidth: Int,
        screenHeight: Int,
        tableauStartY: Float
    ) {
        val wasteLeftScreen = screenWidth * 62 / 100
        val wasteRightScreen = screenWidth * 78 / 100
        val wasteTopScreen = screenHeight * 22 / 100
        val wasteBottomScreen = tableauStartY - screenHeight / 50  // just above tableau start

        val regionLeft = regionLeft.coerceAtMost(screenWidth.toFloat()).coerceAtLeast(0f)
        val regionRight = regionRight.coerceAtMost(screenWidth.toFloat()).coerceAtLeast(0f)
        val regionTop = regionTop.coerceAtMost(screenHeight.toFloat()).coerceAtLeast(0f)
        val regionBottom = regionBottom.coerceAtMost(screenHeight.toFloat()).coerceAtLeast(0f)

        val region = Rect(regionLeft.toInt(), regionTop.toInt(), regionRight.toInt(), regionBottom.toInt())
        val cardsInRegion = analyzeColorRegionForCards(bitmap = null, region, screenWidth, screenHeight, "waste")

        // Waste pile top card is the first/primary card detected
        gameState.wastePileTopCard = if (cardsInRegion.isNotEmpty()) {
            cardsInRegion.firstOrNull()
        } else null
    }

    /**
     * Detect Tableau Columns 1-7.
     * Columns start at Y=33% and go to bottom of screen.
     */
    private fun detectTableauColumns(
        gameState: GameState,
        screenWidth: Int,
        screenHeight: Int,
        columnWidth: Float,
        tableauStartY: Float,
        tableauEndY: Float
    ) {
        gameState.tableauColumns = emptyList()

        for (colIndex in 0 until 7) {
            val colCenterX = (colIndex * columnWidth) + (columnWidth / 2)
            val colCenterY = tableauStartY + (screenHeight / 6).toFloat()  // roughly middle of tableau area

            // Calculate column detection region: ±17.5% of column width horizontally,
            // from tableauStartY to tableauEndY vertically
            val regionLeft = Math.max(0f, colCenterX - columnWidth / 8f).coerceAtMost(screenWidth.toFloat()).coerceAtLeast(0f)
            val regionRight = Math.min(screenWidth.toFloat(), colCenterX + columnWidth / 8f).coerceAtMost(screenWidth.toFloat()).coerceAtLeast(0f)
            val regionTop = tableauStartY.coerceAtMost(screenHeight.toFloat()).coerceAtLeast(0f)
            val regionBottom = tableauEndY.coerceAtMost(screenHeight.toFloat()).coerceAtLeast(0f)

            val region = Rect(regionLeft.toInt(), regionTop.toInt(), regionRight.toInt(), regionBottom.toInt())
            val cardsInColumn = analyzeColorRegionForCards(bitmap = null, region, screenWidth, screenHeight, "tableau_$colIndex")

            // Determine top card position - approximate: slightly below start of column
            var topCardY = tableauStartY + 20  // a bit below the top start

            gameState.tableauColumns.add(TableauColumn(
                columnIndex = colIndex + 1,
                cards = cardsInColumn,
                topCardPosition = Pair(colCenterX.toFloat(), topCardY.toFloat())
            ))
        }
    }

    /**
     * Analyze a region of the bitmap for card color/suit indicators.
     * This is a pixel color analysis fallback when OCR is not available.
     */
    private fun analyzeColorRegionForCards(
        bitmap: Bitmap?,  // Not used in proportional version - analysis is coordinate-based
        region: Rect,
        screenWidth: Int,
        screenHeight: Int,
        regionName: String
    ): List<Card> {
        val resultCards = mutableListOf<Card>()

        // Ensure region is within screen bounds
        val clampedLeft = Math.max(0, region.left)
        val clampedRight = Math.min(screenWidth, region.right)
        val clampedTop = Math.max(0, region.top)
        val clampedBottom = Math.min(screenHeight, region.bottom)

        if (clampedLeft >= clampedRight || clampedTop >= clampedBottom) {
            return resultCards
        }

        // Sample pixels across the region
        // Use a grid sample density based on region size
        val regionWidth = clampedRight - clampedLeft
        val regionHeight = clampedBottom - clampedTop
        val sampleStep = maxOf(1, min(regionWidth, regionHeight) / 6)

        var redCount = 0
        var blueCount = 0
        var blackCount = 0

        // Track center of sampled region for debugging
        val centerX = region.left + regionWidth / 2
        val centerY = region.top + regionHeight / 2

        // Sample pixels - in a real implementation with bitmap, we'd sample actual pixels
        // For now, we'll create placeholder cards based on color dominance
        // The actual bitmap analysis would go here when image capture is integrated

        // Determine dominant suit color
        val dominantColor = when {
            redCount > blueCount + blackCount && redCount > 3 -> "red"   // Hearts or Diamonds
            blueCount > blackCount && blueCount > 3 -> "black"          // Spades or Clubs
            else -> "unknown"
        }

        // If we have significant color detection, create placeholder cards
        if (redCount > 3 || blueCount > 3 || blackCount > 3) {
            val rank = when {
                redCount > blueCount + blackCount -> Rank.ACE  // Placeholder
                blueCount > blackCount -> Rank.KING  // Placeholder
                else -> Rank.TWO
            }
            val suit = when (dominantColor) {
                "red" -> when (blueCount > redCount) Suit.CLUBS else Suit.HEARTS
                "black" -> when (blueCount > redCount) Suit.SPADES else Suit.CLUBS
                else -> Suit.HEARTS
            }
            resultCards.add(Card(rank, suit))
        }

        return resultCards
    }
}