package com.jawaker.solitaire.model

/**
 * Represents a move that the auto-bot can execute.
 */
data class BotMove(
    /** Type of move to execute */
    val type: Type,
    /** The card being moved (or null for stock taps) */
    val card: Card?,
    /** The last card in a sequence being moved (for tableau moves) */
    val lastCard: Card?,
    /** Human-readable description of the move */
    val description: String,
    /** Start X coordinate (optional, relative to screen, 0-1 range) */
    val startX: Float? = null,
    /** Start Y coordinate (optional, relative to screen, 0-1 range) */
    val startY: Float? = null,
    /** End X coordinate (optional, relative to screen, 0-1 range) */
    val endX: Float? = null,
    /** End Y coordinate (optional, relative to screen, 0-1 range) */
    val endY: Float? = null
)

/**
 * Enum representing different types of moves the bot can perform.
 */
enum class Type {
    /** Tap gesture at specified coordinates */
    TAP,
    /** Drag and drop gesture from start to end coordinates */
    DRAG,
    /** Move card to foundation pile */
    FOUNDATION,
    /** Tap stock pile to draw cards */
    STOCK_TAP,
    /** Move between tableau columns */
    TABLEAU
}