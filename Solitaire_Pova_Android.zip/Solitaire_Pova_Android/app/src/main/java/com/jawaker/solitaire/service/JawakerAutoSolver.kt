package com.jawaker.solitaire.service

import com.jawaker.solitaire.model.BotMove
import com.jawaker.solitaire.model.Card
import com.jawaker.solitaire.model.GameState
import com.jawaker.solitaire.model.Rank
import com.jawaker.solitaire.model.Suit
import com.jawaker.solitaire.model.TableauColumn

/**
 * The main auto-solver that determines the best move based on current game state.
 * Implements all priority rules for Jawaker/Solitaire gameplay.
 * Rules ordered by priority (1 = highest priority).
 */
class JawakerAutoSolver {

    /**
     * Determine the next move based on current game state.
     * Returns null if no valid move is found.
     */
    fun decideNextMove(gameState: GameState): BotMove? {
        // Priority 1: Move Aces and Twos to foundations immediately
        val aceOrTwoMove = checkForAceOrTwoMove(gameState)
        if (aceOrTwoMove != null) return aceOrTwoMove

        // Priority 2: Check for valid tableau moves (sub-stack moving)
        val tableauMove = checkTableauMove(gameState)
        if (tableauMove != null) return tableauMove

        // Priority 3: Check foundation moves (safe moves to foundations)
        val foundationMove = checkFoundationMoves(gameState)
        if (foundationMove != null) return foundationMove

        // Priority 4: Check waste pile moves
        val wasteMove = checkWasteMoves(gameState)
        if (wasteMove != null) return wasteMove

        // Priority 5: Recycle stock if no moves available
        return checkStockRecycle(gameState)
    }

    /**
     * Rule 1: If any Ace (A) or Two (2) appears, move it immediately to foundations.
     * Priority highest - as soon as A or 2 is visible anywhere, move to foundations.
     */
    private fun checkForAceOrTwoMove(gameState: GameState): BotMove? {
        // Check waste pile top card first
        if (gameState.wastePileTopCard != null) {
            val wasteCard = gameState.wastePileTopCard!!
            when (wasteCard.rank) {
                Rank.ACE -> {
                    return BotMove(
                        BotMove.Type.FOUNDATION,
                        wasteCard,
                        null,
                        "Move Ace ${wasteCard.suit} to foundation"
                    )
                }
                Rank.TWO -> {
                    return BotMove(
                        BotMove.Type.FOUNDATION,
                        wasteCard,
                        null,
                        "Move Two ${wasteCard.suit} to foundation"
                    )
                }
            }
        }

        // Check foundation piles - if any foundation can accept an Ace or Two
        for (foundation in gameState.foundationPiles) {
            // Empty foundation needs Ace first
            if (foundation.cards.isEmpty()) {
                // Check if waste or tableau has an Ace
                for (card in getAllDiscoveredCards(gameState)) {
                    if (card.rank == Rank.ACE) {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            card,
                            null,
                            "Move Ace ${card.suit} to empty foundation"
                        )
                    }
                }
            } else {
                // Foundation has cards - check if top can accept Ace or Two
                val topCard = foundation.cards.last()
                when (topCard.rank) {
                    Rank.KING -> {
                        // Foundations go A-K, so if King is on top, we need Queen next
                        // Actually foundations start at A, so King would only be valid if Ace-2-3-4 already there
                    }
                    Rank.ACE -> {
                        // Can always move Ace to foundation if it's not already there
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            topCard,
                            null,
                            "Move Ace ${topCard.suit} to foundation"
                        )
                    }
                    Rank.TWO -> {
                        // Can move Two if Ace is already on this foundation
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            topCard,
                            null,
                            "Move Two ${topCard.suit} to foundation"
                        )
                    }
                }
            }
        }

        // Check tableau columns for Aces and Twos
        for (column in gameState.tableauColumns) {
            for (card in column.cards) {
                when (card.rank) {
                    Rank.ACE -> {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            card,
                            null,
                            "Move Ace ${card.suit} from tableau to foundation"
                        )
                    }
                    Rank.TWO -> {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            card,
                            null,
                            "Move Two ${card.suit} from tableau to foundation"
                        )
                    }
                }
            }
        }

        return null
    }

    /**
     * Get all discovered cards from the game state.
     */
    private fun getAllDiscoveredCards(gameState: GameState): List<Card> {
        val allCards = mutableListOf<Card>()

        // Add waste pile top card
        if (gameState.wastePileTopCard != null) {
            allCards.add(gameState.wastePileTopCard!!)
        }

        // Add foundation pile cards
        for (foundation in gameState.foundationPiles) {
            allCards.addAll(foundation.cards)
        }

        // Add tableau column cards
        for (column in gameState.tableauColumns) {
            allCards.addAll(column.cards)
        }

        return allCards
    }

    /**
     * Rule 2: Sub-stack moving between tableau columns.
     * Move descending sequences of alternating colors.
     */
    private fun checkTableauMove(gameState: GameState): BotMove? {
        // For each source column
        for (sourceColIndex in gameState.tableauColumns.indices) {
            val sourceCol = gameState.tableauColumns[sourceColIndex]

            // Find descending sequences with alternating colors
            val sequences = findDescendingSequences(sourceCol)

            for (sequence in sequences) {
                if (sequence.cards.size < 2) continue

                // Get the target column that can accept this sequence
                val targetCol = findTargetColumnForSequence(gameState, sourceCol, sequence)

                if (targetCol != null) {
                    val startX = sequence.startPosition.first
                    val startY = sequence.startPosition.second
                    val endX = targetCol.topCardPosition.first
                    val endY = targetCol.topCardPosition.second

                    return BotMove(
                        BotMove.Type.TABLEAU,
                        sequence.firstCard,
                        sequence.lastCard,
                        "Move stack of ${sequence.cards.size} cards from column ${sourceCol.columnIndex} to column ${targetCol.columnIndex}",
                        startX, startY, endX, endY
                    )
                }
            }
        }

        return null
    }

    /**
     * Find descending sequences with alternating colors in a tableau column.
     * A descending sequence means each card is one rank lower than the previous,
     * and alternating colors (red/black) between consecutive cards.
     */
    private fun findDescendingSequences(column: TableauColumn): List<SequenceInfo> {
        val sequences = mutableListOf<SequenceInfo>()
        var currentSequence = mutableListOf<Card>()

        for (i in column.cards.indices) {
            val card = column.cards[i]

            if (i == 0) {
                currentSequence.add(card)
            } else {
                val previousCard = column.cards[i - 1]

                // Check if card is one rank lower than previous
                val isDescending = card.rank.ordinal - previousCard.rank.ordinal == 1
                // Check if colors alternate (red/black)
                val isAlternatingColor = card.suit.color != previousCard.suit.color

                if (isDescending && isAlternatingColor) {
                    currentSequence.add(card)
                } else {
                    // Save current sequence if it has at least 2 cards
                    if (currentSequence.size >= 2) {
                        sequences.add(SequenceInfo(
                            currentSequence.first(),
                            currentSequence.last(),
                            currentSequence,
                            calculateStartPosition(currentSequence)
                        ))
                    }
                    currentSequence = mutableListOf<Card>()
                    currentSequence.add(card)
                }
            }
        }

        // Save the last sequence
        if (currentSequence.size >= 2) {
            sequences.add(SequenceInfo(
                currentSequence.first(),
                currentSequence.last(),
                currentSequence,
                calculateStartPosition(currentSequence)
            ))
        }

        return sequences
    }

    private fun calculateStartPosition(cards: List<Card>): Pair<Float, Float> {
        // Return the position of the first card in the sequence
        if (cards.isEmpty()) return Pair(0f, 0f)
        // In a full implementation, this would use the column's X position
        // For now, return approximate position
        return Pair(0f, 0f)
    }

    /**
     * Find a valid target column for a sequence following solitaire rules.
     * Target must accept the sequence's first card (one rank lower, alternating color)
     * and must not create an infinite loop situation.
     */
    private fun findTargetColumnForSequence(
        gameState: GameState,
        sourceCol: TableauColumn,
        sequence: SequenceInfo
    ): TableauColumn? {
        val targetColor = sourceCol.cards.first().suit.color

        return gameState.tableauColumns.find { targetCol ->
            // Target must accept the sequence's first card
            canAcceptCard(targetCol, sequence.firstCard) &&
                // Check that moving won't create infinite loops
                !willCreateInfiniteLoop(gameState, targetCol, sequence)
        }
    }

    private fun canAcceptCard(column: TableauColumn, card: Card): Boolean {
        if (column.cards.isEmpty()) {
            // Empty column can only accept King or K-starting sequences
            return card.rank == Rank.KING
        }

        val topCard = column.cards.last()
        // Card must be one rank lower and alternate color
        val isOneRankLower = card.rank.ordinal - topCard.rank.ordinal == 1
        val isAlternatingColor = card.suit.color != topCard.suit.color

        return isOneRankLower && isAlternatingColor
    }

    private fun willCreateInfiniteLoop(
        gameState: GameState,
        targetCol: TableauColumn,
        sequence: SequenceInfo
    ): Boolean {
        // Simple check: if moving this sequence would just allow the same
        // sequence to be moved back, it's potentially an infinite loop
        // Full implementation would track move history to prevent this
        false
    }

    /**
     * Rule 3: Check foundation moves - safe moves to foundations.
     * Also check for Kings that can go to empty tableau columns.
     */
    private fun checkFoundationMoves(gameState: GameState): BotMove? {
        // Check for safe foundation moves (3-K of same suit)
        // Priority: move cards to foundations if it helps the game state
        for (card in gameState.discoveredCards) {
            when (card.rank) {
                Rank.THREE, Rank.FOUR, Rank.FIVE, Rank.SIX,
                    Rank.SEVEN, Rank.EIGHT, Rank.NINE, Rank.TEN,
                    Rank.JACK, Rank.QUEEN, Rank.KING -> {
                    // Check if this card can go to foundation
                    // Foundations are built Ace to King by suit
                    val suitableFoundation = gameState.foundationPiles.find { foundation ->
                        // Foundation must either be empty (waiting for Ace) or have top card
                        // that is one rank lower and same suit
                        if (foundation.cards.isEmpty()) {
                            // Empty foundation needs Ace - skip non-Ace cards
                            false
                        } else {
                            val topCard = foundation.cards.last()
                            // Must be next rank up and same suit
                            val isNextRank = card.rank.ordinal - topCard.rank.ordinal == 1
                            val isSameSuit = card.suit == foundation.suit

                            isNextRank && isSameSuit
                        }
                    }

                    if (suitableFoundation != null) {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            card,
                            null,
                            "Move ${card.rank}${card.suit} to foundation"
                        )
                    }
                }
            }
        }

        // Also check waste pile top card for foundation moves
        if (gameState.wastePileTopCard != null) {
            val wasteCard = gameState.wastePileTopCard!!
            when (wasteCard.rank) {
                Rank.THREE, Rank.FOUR, Rank.FIVE, Rank.SIX,
                    Rank.SEVEN, Rank.EIGHT, Rank.NINE, Rank.TEN,
                    Rank.JACK, Rank.QUEEN, Rank.KING -> {
                    val suitableFoundation = gameState.foundationPiles.find { foundation ->
                        if (foundation.cards.isEmpty()) false
                        else {
                            val topCard = foundation.cards.last()
                            val isNextRank = wasteCard.rank.ordinal - topCard.rank.ordinal == 1
                            val isSameSuit = wasteCard.suit == foundation.suit
                            isNextRank && isSameSuit
                        }
                    }

                    if (suitableFoundation != null) {
                        return BotMove(
                            BotMove.Type.FOUNDATION,
                            wasteCard,
                            null,
                            "Move ${wasteCard.rank}${wasteCard.suit} from waste to foundation"
                        )
                    }
                }
            }
        }

        return null
    }

    /**
     * Rule 4: Check waste pile moves.
     * Evaluate waste pile top card for valid moves to foundations or tableau.
     */
    private fun checkWasteMoves(gameState: GameState): BotMove? {
        val wasteTop = gameState.wastePileTopCard

        if (wasteTop == null) return null

        // Check if waste top card can go to foundation
        val foundationMove = checkFoundationCardMove(wasteTop, gameState)
        if (foundationMove != null) return foundationMove

        // Check if waste top card can go to tableau
        val tableauMove = checkTableauCardMove(wasteTop, gameState)
        if (tableauMove != null) return tableauMove

        return null
    }

    private fun checkFoundationCardMove(card: Card, gameState: GameState): BotMove? {
        val suitableFoundation = gameState.foundationPiles.find { foundation ->
            if (foundation.cards.isEmpty()) false
            else {
                val topCard = foundation.cards.last()
                val isNextRank = card.rank.ordinal - topCard.rank.ordinal == 1
                val isSameSuit = card.suit == foundation.suit

                isNextRank && isSameSuit
            }
        }

        return if (suitableFoundation != null) {
            BotMove(
                BotMove.Type.FOUNDATION,
                card,
                null,
                "Move ${card.rank}${card.suit} from waste to foundation"
            )
        } else null
    }

    private fun checkTableauCardMove(card: Card, gameState: GameState): BotMove? {
        // Try each tableau column
        for (columnIndex in gameState.tableauColumns.indices) {
            val targetCol = gameState.tableauColumns[columnIndex]

            if (canPlaceOnTableau(card, targetCol)) {
                // Determine start coordinates from waste pile area proportionally
                val startX = 62f / 100f  // Waste pile X area start (62% from left)
                val startY = 22f / 100f  // Waste pile Y (22% from top)
                val endX = targetCol.topCardPosition.first
                val endY = targetCol.topCardPosition.second

                return BotMove(
                    BotMove.Type.TABLEAU,
                    card,
                    null,
                    "Move ${card.rank}${card.suit} from waste to column ${targetCol.columnIndex}",
                    startX, startY, endX, endY
                )
            }
        }

        return null
    }

    private fun canPlaceOnTableau(card: Card, column: TableauColumn): Boolean {
        if (column.cards.isEmpty()) {
            // Empty column accepts only King
            return card.rank == Rank.KING
        }

        val topCard = column.cards.last()
        // Card must be one rank lower and alternate color
        val isOneRankLower = card.rank.ordinal - topCard.rank.ordinal == 1
        val isAlternatingColor = card.suit.color != topCard.suit.color

        return isOneRankLower && isAlternatingColor
    }

    /**
     * Rule 5: Stock recycle - tap the stock pile when no moves available.
     * Tap stock pile to draw cards.
     */
    private fun checkStockRecycle(gameState: GameState): BotMove? {
        // This is a special move type - just tapping the stock pile
        // Stock pile located at top-right (~87% from left, 22% from top)
        return BotMove(
            BotMove.Type.STOCK_TAP,
            null,
            null,
            "Tap stock pile to draw cards"
        )
    }
}

/**
 * Helper data class for storing sequence information during tableau move detection.
 */
data class SequenceInfo(
    val firstCard: Card,
    val lastCard: Card,
    val cards: List<Card>,
    val startPosition: Pair<Float, Float>
)