package com.jawaker.solitaire

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Intent
import.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private var mFloatingView: View? = null
    private var mParams: WindowManager.LayoutParams? = null
    private var mAutoService: AutoTouchAccessibilityService? = null
    private var isRunning = false
    private var isPaused = false
    private var startTime: Long = 0
    private var elapsedTime = 0L
    private var handler = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        // Check for required permissions
        checkAndRequestPermissions()

        // Initialize UI buttons
        btnStart.setOnClickListener { startBot() }
        btnStop.setOnClickListener { stopBot() }
        btnPause.setOnClickListener { pauseResumeBot() }
        seekSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                txtSpeedValue.text = progress.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun checkAndRequestPermissions() {
        // Check SYSTEM_ALERT_WINDOW permission
        if (!hasSystemAlertWindowPermission()) {
            requestSystemAlertWindowPermission()
            return
        }

        // Check Accessibility permission
        if (!isAccessibilityEnabled()) {
            requestAccessibilityPermission()
            return
        }

        // If both permissions granted, initialize the service
        initializeService()
    }

    private fun hasSystemAlertWindowPermission(): Boolean {
        return android.provider.Settings.canDrawOverlays(this)
    }

    private fun requestSystemAlertWindowPermission() {
        val intent = android.provider.Settings
            .actionMANAGE_OVERLAY_PERMISSION
            .let { i -> i.setData(android.net.Uri.parse("package:" + packageName)) }
        startActivityForResult(intent, 1)
    }

    private fun isAccessibilityEnabled(): Boolean {
        try {
            val serviceInfo = packageManager
                .getServiceInfo(
                    componentName,
                    PackageManager.GET_META_DATA
                )
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun requestAccessibilityPermission() {
        val intent = Intent(android.settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }

    private fun initializeService() {
        mAutoService = AutoTouchAccessibilityService(this)
        updateStatus("جاري التهيئة...")
    }

    private fun updateStatus(message: String) {
        txtStatus.text = message
    }

    private fun startBot() {
        if (isRunning) return

        // Check permissions again
        if (!hasSystemAlertWindowPermission()) {
            requestSystemAlertWindowPermission()
            return
        }

        isRunning = true
        isPaused = false
        startTime = System.currentTimeMillis() - elapsedTime
        btnStart.isEnabled = false
        btnStop.isEnabled = true
        btnPause.isEnabled = true
        updateStatus("جاري تحليل الشاشة...")

        // Start the analysis loop in a coroutine
        lifecycleScope.launch {
            while (isRunning && !isPaused) {
                try {
                    // Capture screen and analyze
                    val screenWidth = windowManager.defaultDisplay.width
                    val screenHeight = windowManager.defaultDisplay.height

                    // Analyze the screen using CardVisionEngine
                    // In a full implementation, we would capture the actual screen here
                    // For now, we'll simulate with a delay
                    delay(1000)  // Simulate 1 second analysis time

                    // Get game state from vision engine
                    // gameState = cardVisionEngine.analyzeScreen(...)

                    // Decide on next move using auto-solver
                    // val move = JawakerAutoSolver().decideNextMove(gameState)

                    // Execute move if found
                    // if (move != null) {
                    //     mAutoService?.performMove(move, screenWidth, screenHeight)
                    // }

                    // Update UI
                    updateStatus("جاري المعالجة... ${/* moves count */}")

                } catch (e: Exception) {
                    e.printStackTrace()
                    updateStatus("خطأ: ${e.message}")
                    break
                }
            }
        }
    }

    private fun pauseResumeBot() {
        isPaused = !isPaused
        btnPause.text = if (isPaused) "استئناف" else "إيقاف مؤقت"
        updateStatus(if (isPaused) "مؤقتًا متوقف" : "جاري المعالجة...")
    }

    private fun stopBot() {
        isRunning = false
        isPaused = false
        btnStart.isEnabled = true
        btnStop.isEnabled = false
        btnPause.isEnabled = false
        updateStatus("موقف")
        btnStart.text = "ابدأ"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            // Permission granted, restart the activity to re-check
            if (hasSystemAlertWindowPermission()) {
                recreate()
            }
        }
    }
}