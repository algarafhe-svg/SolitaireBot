package com.jawaker.solitaire.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.widget.RemoteViews
import android.widget.RemoteViewsService

/**
 * Service that provides remote views for bot notification.
 * Displays bot status and moves count in the notification.
 */
class BotNotificationService : RemoteViewsService() {

    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory {
        return object : RemoteViewsFactory {
            private var mDataSet: Int = 0

            override fun getCount(): Int {
                return mDataSet
            }

            override fun getItem(position: Int): Any? {
                return position
            }

            override fun getItemId(position: Int): Long {
                return position.toLong()
            }

            override fun onDestroy() {
                mDataSet = 0
            }

            override fun onInvalidate() {
                notifyDataSetChanged()
            }

            override fun registerObserver(arg0: AndroidX.databinding.ObserverRegistry?) {
                // Nothing needed
            }

            override fun unregisterObserver(arg0: AndroidX.databinding.ObserverRegistry?) {
                // Nothing needed
            }

            override fun notifyDataSetChanged() {
                mDataSet = mDataSet + 1
                super.notifyDataSetChanged()
            }

            override fun getViewTypeCount(): Int {
                return 1
            }

            override fun hasStableIds(): Boolean {
                return true
            }

            override fun createViewAt(position: Int): RemoteViews? {
                val remoteViews = RemoteViews(
                    applicationContext.packageName,
                    android.R.layout.simple_list_item_1
                )
                remoteViews.setTextViewText(
                    android.R.id.text1,
                    "Bot Status: ${position + 1}"
                )
                return remoteViews
            }

            override fun deleteViewAt(position: Int): Unit {
                // Nothing needed
            }

            override fun updateViewAt(view: RemoteViews, position: Int): Unit {
                // Nothing needed - views created on demand
            }
        }
    }
}