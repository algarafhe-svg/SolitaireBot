package com.jawaker.solitaire.service

import android.accessibilityservice.AccessibilityService
import android.gesture.GestureDescription
import android.graphics.PointF
import android.os.Build
import android.os.Handler
import android.util.Log
import android.view.*
import android.widget.Toast
import com.jawaker.solitaire.model.BotMove
import com.jawaker.solitaire.model.Card
import com.jawaker.solitaire.model.Rank
import com.jawaker.solitaire.model.Suit
import com.jawaker.solitaire.model.Type

/**
 * Accessibility service that performs automatic touches and drags for the auto-play bot.
 * Uses proportional coordinates based on actual screen dimensions.
 * No hardcoded emulator 900x1600 pixel values.
 */
class AutoTouchAccessibilityService(context: Context) : AccessibilityService() {

    private lateinit var handler: Handler
    private var isProcessingMove: Boolean = false
    private var accessibilityEnabled: Boolean = false

    init {
        handler = Handler(context.mainLooper)
        checkAccessibilityEnabled()
    }

    private fun checkAccessibilityEnabled() {
        try {
            val serviceInfo = packageManager
                .getServiceInfo(componentName, PackageManager.GET_META_DATA)
            accessibilityEnabled = true
        } catch (e: Exception) {
            accessibilityEnabled = false
            Log.e("AutoTouchAS", "Accessibility service not enabled properly")
        }
    }

    /**
     * Main entry point - perform a move based on BotMove description.
     * Uses proportional coordinates scaled to actual screen dimensions.
     */
    fun performMove(move: BotMove?, screenWidth: Int, screenHeight: Int) {
        if (move == null || isProcessingMove) return

        // Check if accessibility is enabled
        if (!accessibilityEnabled) {
            checkAccessibilityEnabled()
            if (!accessibilityEnabled) {
                updateStatus("Error: Accessibility not enabled")
                return
            }
        }

        isProcessingMove = true

        try {
            when (move.type) {
                BotMove.Type.TAP -> performTapMove(move, screenWidth, screenHeight)
                BotMove.Type.DRAG -> performDragMove(move, screenWidth, screenHeight)
                BotMove.Type.FOUNDATION -> performFoundationMove(move, screenWidth, screenHeight)
                BotMove.Type.STOCK_TAP -> performStockTapMove(screenWidth, screenHeight)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            updateStatus("Error: ${e.message}")
        } finally {
            isProcessingMove = false
        }
    }

    /**
     * Perform a tap move at calculated proportional coordinates.
     */
    private fun performTapMove(move: BotMove, screenWidth: Int, screenHeight: Int) {
        val (x, y) = getTapPixels(move, screenWidth, screenHeight)
        val gesture = GestureDescription.Builder()

        // CRITICAL FIX: Move 4px to register the touch event
        val tapSpec = TouchGestureSpec(
            x.toFloat(),
            y.toFloat(),
            (x + 4f).toFloat(),
            (y + 4f).toFloat(),
            120
        )

        gesture.addStroke(tapSpec)

        // Pass gesture result callback for diagnostics
        dispatchGesture(gesture, object : onGestureEventListener {
            override fun onGestureEvent(event: Int) {
                // Intermediate events
            }
            override fun onCompleted(success: Boolean) {
                val status = if (success) {
                    "✓ Tap successful at (${formatCoord(x)}dp, ${formatCoord(y)}dp)"
                } else {
                    "✗ Tap FAILED at (${formatCoord(x)}dp, ${formatCoord(y)}dp)"
                }
                updateStatus(status)
                Log.d("AutoTouchAS", status)
                showTouchFeedback(x, y, success)
                isProcessingMove = false
            }
        }, null)
    }

    /**
     * Perform a drag and drop move at calculated proportional coordinates.
     */
    private fun performDragMove(move: BotMove, screenWidth: Int, screenHeight: Int) {
        val (startX, startY, endX, endY) = getDragPixels(move, screenWidth, screenHeight)
        val gesture = GestureDescription.Builder()

        // Drag stroke from start to end
        val dragSpec = TouchGestureSpec(
            startX.toFloat(),
            startY.toFloat(),
            endX.toFloat(),
            endY.toFloat(),
                300
        )

        gesture.addStroke(dragSpec)

        dispatchGesture(gesture, object : onGestureEventListener {
            override fun onGestureEvent(event: Int) {
                // Intermediate events
            }
            override fun onCompleted(success: Boolean) {
                val status = if (success) {
                    "✓ Drag successful from (${formatCoord(startX)}dp, ${formatCoord(startY)}dp) to (${formatCoord(endX)}dp, ${formatCoord(endY)}dp)"
                } else {
                    "✗ Drag FAILED"
                }
                updateStatus(status)
                Log.d("AutoTouchAS", status)
                isProcessingMove = false
            }
        }, null)
    }

    /**
     * Perform a foundation pile move.
     */
    private fun performFoundationMove(move: BotMove, screenWidth: Int, screenHeight: Int) {
        val (x, y) = getTapPixels(move, screenWidth, screenHeight)
        val gesture = GestureDescription.Builder()

        val tapSpec = TouchGestureSpec(
            x.toFloat(),
            y.toFloat(),
            (x + 4f).toFloat(),
            (y + 4f).toFloat(),
            120
        )

        gesture.addStroke(tapSpec)

        dispatchGesture(gesture, object : onGestureEventListener {
            override fun onGestureEvent(event: Int) {
                // Intermediate events
            }
            override fun onCompleted(success: Boolean) {
                val cardInfo = if (move.card != null) {
                    "${move.card!.rank} ${move.card!.suit}"
                } else {
                    "Foundation"
                }
                val status = if (success) {
                    "✓ Moved $cardInfo to foundation"
                } else {
                    "✗ Failed to move to foundation"
                }
                updateStatus(status)
                Log.d("AutoTouchAS", status)
                isProcessingMove = false
            }
        }, null)
    }

    /**
     * Perform a stock pile tap move.
     */
    private fun performStockTapMove(screenWidth: Int, screenHeight: Int) {
        val stockX = screenWidth * 87 / 100  // 87% from left
        val stockY = screenHeight * 22 / 100  // 22% from top

        val gesture = GestureDescription.Builder()
        val tapSpec = TouchGestureSpec(
            stockX.toFloat(),
            stockY.toFloat(),
            (stockX + 4f).toFloat(),
            (stockY + 4f).toFloat(),
            120
        )

        gesture.addStroke(tapSpec)

        dispatchGesture(gesture, object : onGestureEventListener {
            override fun onGestureEvent(event: Int) {
                // Intermediate events
            }
            override fun onCompleted(success: Boolean) {
                val status = if (success) {
                    "✓ Stock pile tapped"
                } else {
                    "✗ Stock tap failed"
                }
                updateStatus(status)
                Log.d("AutoTouchAS", status)
                isProcessingMove = false
            }
        }, null)
    }

    /**
     * Get tap coordinates with proper offset from card rank text.
     * Uses proportional coordinates based on screen dimensions.
     */
    private fun getTapPixels(move: BotMove, screenWidth: Int, screenHeight: Int): Pair<Float, Float> {
        return when (move.type) {
            BotMove.Type.TAP, BotMove.Type.FOUNDATION -> {
                val offsetY = screenHeight * 8 / 100  // 8% from bottom of card rank area
                val baseX = (move.startX ?: 0.5f * screenWidth + move.endX ?: 0.5f * screenWidth) / 2
                val baseY = (move.startY ?: 0.5f * screenHeight + move.endY ?: 0.5f * screenHeight) / 2
                Pair(baseX, baseY + offsetY)
            }
            BotMove.Type.STOCK_TAP -> {
                Pair(screenWidth * 87f / 100f, screenHeight * 22f / 100f)  // Stock pile center
            }
            else -> Pair(0f, 0f)
        }
    }

    /**
     * Get drag pixels in proportional coordinates for actual screen dimensions.
     */
    private fun getDragPixels(move: BotMove, screenWidth: Int, screenHeight: Int): FourFloatPair {
        return when (move.type) {
            BotMove.Type.DRAG -> {
                val startX = move.startX ?: screenWidth * 0.5f / 100f
                val startY = move.startY ?: screenHeight * 0.22f
                val endX = move.endX ?: screenWidth * 0.5f / 100f
                val endY = move.endY ?: screenHeight * 0.5f / 100f
                // Ensure coordinates are within screen bounds
                val clampedStartX = startX.coerceAtLeast(0f).coerceAtMost(screenWidth.toFloat())
                val clampedStartY = startY.coerceAtLeast(0f).coerceAtMost(screenHeight.toFloat())
                val clampedEndX = endX.coerceAtLeast(0f).coerceAtMost(screenWidth.toFloat())
                val clampedEndY = endY.coerceAtLeast(0f).coerceAtMost(screenHeight.toFloat())
                FourFloatPair(clampedStartX, clampedStartY, clampedEndX, clampedEndY)
            }
            else -> FourFloatPair(0f, 0f, 0f, 0f)
        }
    }

    private data class FourFloatPair(
        val startX: Float,
        val startY: Float,
        val endX: Float,
        val endY: Float
    )

    private data class TouchGestureSpec(
        val startX: Float,
        val startY: Float,
        val endX: Float? = null,
        val endY: Float? = null,
        val duration: Int = 300
    )

    /**
     * Update the status text.
     */
    private fun updateStatus(message: String) {
        try {
            Log.d("AutoTouchAS", message)
        } catch (e: Exception) {
            Log.e("AutoTouchAS", "Failed to update status", e)
        }
    }

    private fun formatCoord(coord: Float): String {
        return "%1.0f".format(coord)
    }

    private interface onGestureEventListener {
        fun onGestureEvent(event: Int)
        fun onCompleted(success: Boolean)
    }
}