package com.jawaker.solitaire.model

import com.jawaker.solitaire.model.Card
import com.jawaker.solitaire.model.FoundationSlot
import com.jawaker.solitaire.model.Rank
import com.jawaker.solitaire.model.Suit
import com.jawaker.solitaire.model.TableauColumn

/**
 * Game state container holding all detected game elements.
 */
data class GameState(
    /** Cards in the stock pile */
    var stockPileCards: List<Card> = emptyList(),
    /** Top card visible in waste pile */
    var wastePileTopCard: Card? = null,
    /** Foundation piles - 4 slots */
    var foundationPiles: List<FoundationSlot> = emptyList(),
    /** Tableau columns - 7 columns */
    var tableauColumns: List<TableauColumn> = emptyList()
)

/**
 * Foundation pile slot containing cards of the same suit.
 */
data class FoundationSlot(
    /** The suit of this foundation pile */
    var suit: Suit? = null,
    /** Cards added to this pile, top is last */
    var cards: List<Card> = emptyList()
)

/**
 * Tableau column containing cards from bottom to top.
 */
data class TableauColumn(
    /** The column index (1-7) */
    var columnIndex: Int = 1,
    /** Cards in this column from bottom to top */
    var cards: List<Card> = emptyList(),
    /** The top-most visible card position (X, Y coordinates) */
    var topCardPosition: Pair<Float, Float> = Pair(0f, 0f)
)