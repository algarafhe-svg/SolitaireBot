plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace "com.jawaker.solitaire"
    compileSdk 33
    defaultConfig {
        applicationId "com.jawaker.solitaire"
        minSdk 24
        targetSdk 33
        versionCode 1
        versionName "1.0"
    }
    buildFeatures {
        viewBinding true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
}